import { Component, Input, AfterViewInit, HostBinding, OnInit } from '@angular/core';

declare var jQuery : any;

@Component({
  selector: 'menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements AfterViewInit, OnInit {
  @HostBinding('class.menu') isMenu: boolean = true;
  @HostBinding('class.dropdown') isDropDown: boolean = false;
  @HostBinding('attr.data-dropdown-menu') isDataDropDownMenu: boolean = false;
  //@HostBinding('class.left') 
  //@HostBinding('class.top-bar-section')
  alignLeft: boolean = true;
  @Input() name: String = "default";
  @Input() top: boolean = false;

  ngAfterViewInit() {
      //jQuery(document).foundation();
  }

  ngOnInit(): void {
    if(this.top){
      this.isDropDown = true;
      this.isDataDropDownMenu = true;
    }
  }

}
